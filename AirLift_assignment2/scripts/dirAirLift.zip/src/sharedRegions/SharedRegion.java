package sharedRegions;

public interface SharedRegion {

}
